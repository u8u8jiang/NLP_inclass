clear all;

num_of_speakers = 6;
for s = 1:num_of_speakers
    speaker_dir = ['features\speaker' num2str(s, '%02d')];
    file = dir([speaker_dir '\*.txt']);
    temp = [];
    for n = 1:length(file)
        temp = load([file(n).folder '\' file(n).name]);
        feature{s, n} = temp;
        [num_of_features, num_of_frames] = size(temp);
        target(s, n) = str2num(file(n).name(1));
    end
end

[num_of_speakers, num_of_files] = size(feature);
for s = 1:num_of_speakers
    disp(['speaker: ' num2str(s, '%02d')]);
    
    for n1 = 1:num_of_files
        disp(['speaker: ' num2str(s, '%02d') ', file: ' num2str(n1, '%02d')]);
        tic
        for n2 = 1:num_of_files
            [dist, d, D] = dtw(feature{s, n1}', feature{s, n2}');
            if n1 == n2
                dist = inf;
            end
            distance_temp(n1, n2) = dist;
        end
        toc
    end
    
    distance{s, 1} = distance_temp;
    [val, idx] = min(distance_temp');
    prediction(s, :) = ceil(idx / 5) - 1;
    cm{s, 1} = confusionmat(target(s, :), prediction(s, :));
    accuracy(s) = (sum(diag(cm{s, 1})) / sum(cm{s, 1}(:))) * 100;
end